/* ==========================================================================
   Aşk Sayacı & Kilit Ekranı Widget | JavaScript Core Logic
   ========================================================================== */

// --- STATE & INITIAL CONFIG ---
const DEFAULT_STATE = {
  partner1: "Ahmet",
  partner2: "Ayşe",
  startDate: "2024-02-14T14:00",
  avatar1: null,
  avatar2: null
};

let appState = { ...DEFAULT_STATE };
let memories = []; 
let futurePlans = [];
let userNotes = [];
let notifications = [];

// Current Calendar Navigation State
let currentCalDate = new Date();
let currentFutureCalDate = new Date();
let selectedMemoryPhotos = [];
let activeNoteFilter = "all";

let sentNotificationIds = new Set(JSON.parse(localStorage.getItem("love_sent_notif_ids") || "[]"));

// IndexedDB Storage Initialization (Version 4 for user_notes)
const DB_NAME = "LoveCounterAppDB";
const DB_VERSION = 4;
let db = null;

function initDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    
    request.onupgradeneeded = (e) => {
      const dbInstance = e.target.result;
      if (!dbInstance.objectStoreNames.contains("memories")) {
        dbInstance.createObjectStore("memories", { keyPath: "id" });
      }
      if (!dbInstance.objectStoreNames.contains("future_plans")) {
        dbInstance.createObjectStore("future_plans", { keyPath: "id" });
      }
      if (!dbInstance.objectStoreNames.contains("user_notes")) {
        dbInstance.createObjectStore("user_notes", { keyPath: "id" });
      }
      if (!dbInstance.objectStoreNames.contains("notifications")) {
        dbInstance.createObjectStore("notifications", { keyPath: "id" });
      }
    };

    request.onsuccess = (e) => {
      db = e.target.result;
      resolve(db);
    };

    request.onerror = (e) => {
      console.warn("IndexedDB fallback to localStorage", e);
      resolve(null);
    };
  });
}

// --- APP INITIALIZATION ---
document.addEventListener("DOMContentLoaded", async () => {
  await initDB();
  await loadAppState();
  await loadMemories();
  await loadFuturePlans();
  await loadUserNotes();
  await loadNotifications();

  initFloatingHearts();
  startCounterTimer();
  renderCouplesHeader();
  renderCalendar(currentCalDate);
  renderFutureCalendar(currentFutureCalDate);
  renderTimeline();
  renderFuturePlans();
  renderUserNotes();
  renderNotifications();
  setupEventListeners();
  setupPwaInstaller();
  updateAmbientLockscreen();

  checkAndTriggerPlanNotifications();
  checkAndTriggerNoteNotifications();
});

// --- LOAD / SAVE STATE ---
async function loadAppState() {
  const saved = localStorage.getItem("love_counter_state");
  if (saved) {
    try {
      appState = { ...DEFAULT_STATE, ...JSON.parse(saved) };
    } catch (e) {
      console.error(e);
    }
  } else {
    const defaultDate = new Date();
    defaultDate.setFullYear(defaultDate.getFullYear() - 1);
    appState.startDate = defaultDate.toISOString().slice(0, 16);
    saveAppState();
  }
}

function saveAppState() {
  localStorage.setItem("love_counter_state", JSON.stringify(appState));
}

// Memory Operations
async function loadMemories() {
  if (db && db.objectStoreNames.contains("memories")) {
    return new Promise((resolve) => {
      const tx = db.transaction("memories", "readonly");
      const store = tx.objectStore("memories");
      const req = store.getAll();
      req.onsuccess = () => {
        memories = req.result || [];
        resolve(memories);
      };
      req.onerror = () => {
        loadMemoriesFromLS();
        resolve(memories);
      };
    });
  } else {
    loadMemoriesFromLS();
  }
}

function loadMemoriesFromLS() {
  const data = localStorage.getItem("love_counter_memories");
  memories = data ? JSON.parse(data) : [];
}

async function saveMemory(memoryObj) {
  const existingIdx = memories.findIndex(m => m.id === memoryObj.id);
  if (existingIdx >= 0) {
    memories[existingIdx] = memoryObj;
  } else {
    memories.push(memoryObj);
  }

  if (db && db.objectStoreNames.contains("memories")) {
    const tx = db.transaction("memories", "readwrite");
    const store = tx.objectStore("memories");
    store.put(memoryObj);
  }
  localStorage.setItem("love_counter_memories", JSON.stringify(memories));
}

async function deleteMemory(id) {
  memories = memories.filter(m => m.id !== id);
  if (db && db.objectStoreNames.contains("memories")) {
    const tx = db.transaction("memories", "readwrite");
    const store = tx.objectStore("memories");
    store.delete(id);
  }
  localStorage.setItem("love_counter_memories", JSON.stringify(memories));
}

// Future Plans Operations
async function loadFuturePlans() {
  if (db && db.objectStoreNames.contains("future_plans")) {
    return new Promise((resolve) => {
      const tx = db.transaction("future_plans", "readonly");
      const store = tx.objectStore("future_plans");
      const req = store.getAll();
      req.onsuccess = () => {
        futurePlans = req.result || [];
        resolve(futurePlans);
      };
      req.onerror = () => {
        loadFuturePlansFromLS();
        resolve(futurePlans);
      };
    });
  } else {
    loadFuturePlansFromLS();
  }
}

function loadFuturePlansFromLS() {
  const data = localStorage.getItem("love_counter_future_plans");
  futurePlans = data ? JSON.parse(data) : [];
}

async function saveFuturePlan(planObj) {
  const existingIdx = futurePlans.findIndex(p => p.id === planObj.id);
  if (existingIdx >= 0) {
    futurePlans[existingIdx] = planObj;
  } else {
    futurePlans.push(planObj);
  }

  if (db && db.objectStoreNames.contains("future_plans")) {
    const tx = db.transaction("future_plans", "readwrite");
    const store = tx.objectStore("future_plans");
    store.put(planObj);
  }
  localStorage.setItem("love_counter_future_plans", JSON.stringify(futurePlans));

  checkAndTriggerPlanNotifications();
}

async function deleteFuturePlan(id) {
  futurePlans = futurePlans.filter(p => p.id !== id);
  if (db && db.objectStoreNames.contains("future_plans")) {
    const tx = db.transaction("future_plans", "readwrite");
    const store = tx.objectStore("future_plans");
    store.delete(id);
  }
  localStorage.setItem("love_counter_future_plans", JSON.stringify(futurePlans));
}

// User Notes & Reminders Operations
async function loadUserNotes() {
  if (db && db.objectStoreNames.contains("user_notes")) {
    return new Promise((resolve) => {
      const tx = db.transaction("user_notes", "readonly");
      const store = tx.objectStore("user_notes");
      const req = store.getAll();
      req.onsuccess = () => {
        userNotes = req.result || [];
        resolve(userNotes);
      };
      req.onerror = () => {
        loadUserNotesFromLS();
        resolve(userNotes);
      };
    });
  } else {
    loadUserNotesFromLS();
  }
}

function loadUserNotesFromLS() {
  const data = localStorage.getItem("love_counter_notes");
  userNotes = data ? JSON.parse(data) : [];
}

async function saveUserNote(noteObj) {
  const existingIdx = userNotes.findIndex(n => n.id === noteObj.id);
  if (existingIdx >= 0) {
    userNotes[existingIdx] = noteObj;
  } else {
    userNotes.push(noteObj);
  }

  if (db && db.objectStoreNames.contains("user_notes")) {
    const tx = db.transaction("user_notes", "readwrite");
    const store = tx.objectStore("user_notes");
    store.put(noteObj);
  }
  localStorage.setItem("love_counter_notes", JSON.stringify(userNotes));

  checkAndTriggerNoteNotifications();
}

async function deleteUserNote(id) {
  userNotes = userNotes.filter(n => n.id !== id);
  if (db && db.objectStoreNames.contains("user_notes")) {
    const tx = db.transaction("user_notes", "readwrite");
    const store = tx.objectStore("user_notes");
    store.delete(id);
  }
  localStorage.setItem("love_counter_notes", JSON.stringify(userNotes));
}

// Notifications Store Operations
async function loadNotifications() {
  if (db && db.objectStoreNames.contains("notifications")) {
    return new Promise((resolve) => {
      const tx = db.transaction("notifications", "readonly");
      const store = tx.objectStore("notifications");
      const req = store.getAll();
      req.onsuccess = () => {
        notifications = req.result || [];
        resolve(notifications);
      };
      req.onerror = () => {
        loadNotifsFromLS();
        resolve(notifications);
      };
    });
  } else {
    loadNotifsFromLS();
  }
}

function loadNotifsFromLS() {
  const data = localStorage.getItem("love_counter_notifs");
  notifications = data ? JSON.parse(data) : [];
}

async function addNotificationItem(notifObj) {
  notifications.unshift(notifObj);
  if (db && db.objectStoreNames.contains("notifications")) {
    const tx = db.transaction("notifications", "readwrite");
    const store = tx.objectStore("notifications");
    store.put(notifObj);
  }
  localStorage.setItem("love_counter_notifs", JSON.stringify(notifications));
  renderNotifications();
}

async function deleteNotificationItem(id) {
  notifications = notifications.filter(n => n.id !== id);
  if (db && db.objectStoreNames.contains("notifications")) {
    const tx = db.transaction("notifications", "readwrite");
    const store = tx.objectStore("notifications");
    store.delete(id);
  }
  localStorage.setItem("love_counter_notifs", JSON.stringify(notifications));
  renderNotifications();
}

async function clearAllNotifications() {
  notifications = [];
  if (db && db.objectStoreNames.contains("notifications")) {
    const tx = db.transaction("notifications", "readwrite");
    const store = tx.objectStore("notifications");
    store.clear();
  }
  localStorage.setItem("love_counter_notifs", JSON.stringify(notifications));
  renderNotifications();
}

// --- FLOATING HEARTS PARTICLES ---
function initFloatingHearts() {
  const container = document.getElementById("heartParticles");
  if (!container) return;

  setInterval(() => {
    if (container.children.length > 25) return;
    const heart = document.createElement("div");
    heart.className = "floating-heart-particle";
    heart.style.left = Math.random() * 100 + "vw";
    heart.style.animationDuration = (8 + Math.random() * 8) + "s";
    heart.style.fontSize = (14 + Math.random() * 20) + "px";
    heart.innerHTML = ["❤️", "💖", "💕", "💗", "🌸", "✨"][Math.floor(Math.random() * 6)];
    container.appendChild(heart);

    setTimeout(() => {
      heart.remove();
    }, 15000);
  }, 1200);
}

// --- RELATIONSHIP TIMER & REAL-TIME COUNTER CALCULATIONS (EVERY 1000ms = 1 SECOND) ---
function startCounterTimer() {
  updateCounterDisplay();
  
  // Real-time live update loop (Runs every 1000ms / 1 second)
  setInterval(() => {
    updateCounterDisplay();
    updateAmbientClock();
    updateFutureCountdowns();

    // If Widget Canvas Generator is active, update canvas real-time too
    const genView = document.getElementById("generatorModeView");
    if (genView && genView.classList.contains("active")) {
      renderWidgetCanvas();
    }
  }, 1000);

  // Check plan & note notifications every 5 seconds
  setInterval(() => {
    checkAndTriggerPlanNotifications();
    checkAndTriggerNoteNotifications();
  }, 5000);
}

function updateCounterDisplay() {
  if (!appState.startDate) return;

  const start = new Date(appState.startDate);
  const now = new Date();

  if (isNaN(start.getTime())) return;

  let diffMs = now - start;

  if (diffMs < 0) {
    document.getElementById("counterYears").innerText = "0";
    document.getElementById("counterMonths").innerText = "0";
    document.getElementById("counterDays").innerText = "0";
    document.getElementById("counterHours").innerText = "00";
    document.getElementById("counterMinutes").innerText = "00";
    document.getElementById("counterSeconds").innerText = "00";
    document.getElementById("totalDaysVal").innerText = "0";

    document.getElementById("ambYears").innerText = "0";
    document.getElementById("ambMonths").innerText = "0";
    document.getElementById("ambDays").innerText = "0";
    document.getElementById("ambHours").innerText = "00";
    document.getElementById("ambMins").innerText = "00";
    return;
  }

  let years = now.getFullYear() - start.getFullYear();
  let months = now.getMonth() - start.getMonth();
  let days = now.getDate() - start.getDate();

  if (days < 0) {
    months--;
    const prevMonth = new Date(now.getFullYear(), now.getMonth(), 0);
    days += prevMonth.getDate();
  }

  if (months < 0) {
    years--;
    months += 12;
  }

  let hours = now.getHours() - start.getHours();
  let minutes = now.getMinutes() - start.getMinutes();
  let seconds = now.getSeconds() - start.getSeconds();

  if (seconds < 0) {
    minutes--;
    seconds += 60;
  }
  if (minutes < 0) {
    hours--;
    minutes += 60;
  }
  if (hours < 0) {
    days--;
    hours += 24;
  }

  const totalDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  // 1. Update Main Screen Live Heart Counters
  document.getElementById("counterYears").innerText = years;
  document.getElementById("counterMonths").innerText = months;
  document.getElementById("counterDays").innerText = days;
  document.getElementById("counterHours").innerText = String(hours).padStart(2, '0');
  document.getElementById("counterMinutes").innerText = String(minutes).padStart(2, '0');
  document.getElementById("counterSeconds").innerText = String(seconds).padStart(2, '0');
  document.getElementById("totalDaysVal").innerText = totalDays.toLocaleString("tr-TR");

  // 2. REAL-TIME UPDATE for Lockscreen Widget Individual Heart Counters
  document.getElementById("ambYears").innerText = years;
  document.getElementById("ambMonths").innerText = months;
  document.getElementById("ambDays").innerText = days;
  document.getElementById("ambHours").innerText = String(hours).padStart(2, '0');
  document.getElementById("ambMins").innerText = String(minutes).padStart(2, '0');
}

// --- RENDER COUPLES HEADER ---
function renderCouplesHeader() {
  const namesText = `${appState.partner1 || 'Ahmet'} & ${appState.partner2 || 'Ayşe'}`;
  document.getElementById("couplesNames").innerText = namesText;
  document.getElementById("ambientCouplesName").innerText = namesText;

  if (appState.avatar1) {
    document.getElementById("avatar1Img").src = appState.avatar1;
  }
  if (appState.avatar2) {
    document.getElementById("avatar2Img").src = appState.avatar2;
  }

  if (appState.startDate) {
    const d = new Date(appState.startDate);
    const dateFormatted = d.toLocaleDateString("tr-TR", {
      day: "numeric",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
    document.getElementById("startDateDisplay").innerText = `Birliktelik Başlangıcı: ${dateFormatted}`;
  }
}

// --- CALENDARS LOGIC ---
const MONTH_NAMES = [
  "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran",
  "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"
];

function renderCalendar(dateObj) {
  const year = dateObj.getFullYear();
  const month = dateObj.getMonth();

  document.getElementById("calendarMonthYearText").innerText = `${MONTH_NAMES[month]} ${year}`;

  const grid = document.getElementById("calendarDaysGrid");
  grid.innerHTML = "";

  const firstDayIndex = new Date(year, month, 1).getDay();
  const startDay = firstDayIndex === 0 ? 6 : firstDayIndex - 1;

  const totalDaysInMonth = new Date(year, month + 1, 0).getDate();
  const totalDaysInPrevMonth = new Date(year, month, 0).getDate();

  const today = new Date();
  const startDateObj = appState.startDate ? new Date(appState.startDate) : null;

  for (let i = startDay - 1; i >= 0; i--) {
    const dayNum = totalDaysInPrevMonth - i;
    grid.appendChild(createCalendarCell(dayNum, true));
  }

  for (let day = 1; day <= totalDaysInMonth; day++) {
    const cellDateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const cell = createCalendarCell(day, false, cellDateStr);

    if (today.getFullYear() === year && today.getMonth() === month && today.getDate() === day) {
      cell.classList.add("today");
    }

    if (startDateObj && startDateObj.getFullYear() === year && startDateObj.getMonth() === month && startDateObj.getDate() === day) {
      cell.classList.add("anniversary");
    }

    const hasMemories = memories.some(m => m.date === cellDateStr);
    if (hasMemories) {
      const memoryObj = memories.find(m => m.date === cellDateStr);
      const indicator = document.createElement("span");
      indicator.className = "memory-indicator";
      indicator.innerText = memoryObj.category || "❤️";
      cell.appendChild(indicator);
    }

    cell.addEventListener("click", () => openMemoryModalForDate(cellDateStr));
    grid.appendChild(cell);
  }
}

function renderFutureCalendar(dateObj) {
  const year = dateObj.getFullYear();
  const month = dateObj.getMonth();

  document.getElementById("futureCalendarMonthYearText").innerText = `${MONTH_NAMES[month]} ${year}`;

  const grid = document.getElementById("futureCalendarDaysGrid");
  grid.innerHTML = "";

  const firstDayIndex = new Date(year, month, 1).getDay();
  const startDay = firstDayIndex === 0 ? 6 : firstDayIndex - 1;

  const totalDaysInMonth = new Date(year, month + 1, 0).getDate();
  const totalDaysInPrevMonth = new Date(year, month, 0).getDate();

  const today = new Date();

  for (let i = startDay - 1; i >= 0; i--) {
    const dayNum = totalDaysInPrevMonth - i;
    grid.appendChild(createCalendarCell(dayNum, true));
  }

  for (let day = 1; day <= totalDaysInMonth; day++) {
    const cellDateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const cell = createCalendarCell(day, false, cellDateStr);

    if (today.getFullYear() === year && today.getMonth() === month && today.getDate() === day) {
      cell.classList.add("today");
    }

    const plansForDate = futurePlans.filter(p => p.targetDate.startsWith(cellDateStr));
    if (plansForDate.length > 0) {
      const isAllCompleted = plansForDate.every(p => p.status === "completed");
      const indicator = document.createElement("span");
      indicator.className = "memory-indicator";
      indicator.innerText = plansForDate[0].category || (isAllCompleted ? "🎉" : "✨");
      cell.appendChild(indicator);
      cell.style.borderColor = isAllCompleted ? "#2ec4b6" : "#05d9e8";
    }

    cell.addEventListener("click", () => openFutureModalForDate(cellDateStr));
    grid.appendChild(cell);
  }
}

function createCalendarCell(dayNum, isOtherMonth = false, dateStr = "") {
  const cell = document.createElement("div");
  cell.className = `calendar-day-cell ${isOtherMonth ? 'other-month' : ''}`;
  cell.innerText = dayNum;
  if (dateStr) cell.dataset.date = dateStr;
  return cell;
}

// --- TIMELINE LOGIC ---
function renderTimeline() {
  const container = document.getElementById("timelineContainer");
  if (!container) return;

  if (memories.length === 0) {
    container.innerHTML = `
      <div class="glass-card" style="padding: 30px; text-align: center; color: var(--text-muted);">
        <p>Henüz eklenmiş bir anı bulunmuyor ❤️</p>
        <p style="font-size:0.85rem; margin-top: 6px;">Takvim üzerinden bir güne tıklayarak ilk güzel anınızı kaydedin.</p>
      </div>
    `;
    return;
  }

  const sorted = [...memories].sort((a, b) => new Date(b.date) - new Date(a.date));

  container.innerHTML = sorted.map(m => {
    const formattedDate = new Date(m.date).toLocaleDateString("tr-TR", {
      day: "numeric", month: "long", year: "numeric", weekday: "long"
    });

    const photosHtml = m.photos && m.photos.length > 0 ? `
      <div class="memory-photos-row">
        ${m.photos.map(p => `<img src="${p}" class="memory-photo-thumb" onclick="openPhotoViewer('${p}', '${m.title}')">`).join('')}
      </div>
    ` : '';

    return `
      <div class="memory-card glass-card">
        <div class="memory-card-header">
          <div class="memory-title-wrap">
            <span class="memory-emoji">${m.category || '❤️'}</span>
            <div>
              <h4>${escapeHtml(m.title)}</h4>
              <span class="memory-date-tag">${formattedDate}</span>
            </div>
          </div>
          <button class="btn-icon" onclick="openMemoryModalForDate('${m.date}')" title="Düzenle">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
          </button>
        </div>
        ${m.notes ? `<p class="memory-notes-text">${escapeHtml(m.notes)}</p>` : ''}
        ${photosHtml}
      </div>
    `;
  }).join('');
}

// --- FUTURE PLANS LIST & COUNTDOWNS ---
function renderFuturePlans() {
  const container = document.getElementById("futurePlansList");
  if (!container) return;

  if (futurePlans.length === 0) {
    container.innerHTML = `
      <div class="glass-card" style="padding: 24px; text-align: center; color: var(--text-muted); grid-column: 1 / -1;">
        <p>Henüz planlanmış bir gelecek planı yok ✨</p>
        <p style="font-size:0.85rem; margin-top: 4px;">"Yeni Plan Ekle" butonuna tıklayarak seyahat, tatil veya sürpriz planlarınızı ekleyin.</p>
      </div>
    `;
    return;
  }

  const sorted = [...futurePlans].sort((a, b) => {
    if (a.status === b.status) {
      return new Date(a.targetDate) - new Date(b.targetDate);
    }
    return a.status === "completed" ? 1 : -1;
  });

  container.innerHTML = sorted.map(p => {
    const isCompleted = p.status === "completed";
    const targetDateObj = new Date(p.targetDate);
    const formattedDate = targetDateObj.toLocaleDateString("tr-TR", {
      day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit"
    });

    const countdownText = calculateFutureCountdown(targetDateObj, isCompleted);

    return `
      <div class="future-plan-card ${isCompleted ? 'completed' : ''}">
        <div class="plan-card-top">
          <div class="plan-title-wrap">
            <span class="plan-category-icon">${p.category || '✨'}</span>
            <h5>${escapeHtml(p.title)}</h5>
          </div>
          <span class="countdown-badge ${isCompleted ? 'completed-badge' : ''}">${countdownText}</span>
        </div>
        <div class="plan-date-text">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
          ${formattedDate}
        </div>
        ${p.notes ? `<p class="plan-notes">${escapeHtml(p.notes)}</p>` : ''}
        <div class="plan-actions-row">
          <button class="toggle-complete-btn ${isCompleted ? 'done' : ''}" onclick="toggleFuturePlanComplete('${p.id}')">
            ${isCompleted ? '✓ Tamamlandı' : 'Tamamlandı İşaretle'}
          </button>
          <button class="btn-icon" onclick="openFutureModalForEdit('${p.id}')" title="Düzenle">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M11 4H4a2 2 0 0 1-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
          </button>
        </div>
      </div>
    `;
  }).join('');
}

function calculateFutureCountdown(targetDateObj, isCompleted) {
  if (isCompleted) return "🎉 Tamamlandı";

  const now = new Date();
  const diffMs = targetDateObj - now;

  if (diffMs <= 0) return "Günü Geldi! 🥳";

  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  const diffHours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

  if (diffDays === 0) {
    return `${diffHours} Saat Kaldı ⏳`;
  }
  return `${diffDays} Gün ${diffHours} S. Kaldı`;
}

function updateFutureCountdowns() {
  if (document.getElementById("futureSection").classList.contains("active")) {
    renderFuturePlans();
  }
}

async function toggleFuturePlanComplete(id) {
  const plan = futurePlans.find(p => p.id === id);
  if (plan) {
    plan.status = plan.status === "completed" ? "planned" : "completed";
    await saveFuturePlan(plan);
    renderFuturePlans();
    renderFutureCalendar(currentFutureCalDate);
  }
}

// --- USER NOTES & REMINDERS LOGIC (NEW SECTION) ---
function renderUserNotes() {
  const container = document.getElementById("userNotesGrid");
  if (!container) return;

  let filtered = [...userNotes];
  if (activeNoteFilter === "reminder") {
    filtered = filtered.filter(n => n.reminderEnabled);
  } else if (activeNoteFilter === "love") {
    filtered = filtered.filter(n => n.category === "💖");
  }

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="glass-card" style="padding: 24px; text-align: center; color: var(--text-muted); grid-column: 1 / -1;">
        <p>Henüz kaydedilmiş özel bir not yok 📝</p>
        <p style="font-size:0.85rem; margin-top: 4px;">"Yeni Not & Alarm Ekle" butonuna tıklayarak sevgilinize notlar veya hatırlatıcılar kurun.</p>
      </div>
    `;
    return;
  }

  const sorted = filtered.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));

  container.innerHTML = sorted.map(n => {
    let reminderText = "";
    if (n.reminderEnabled && n.reminderDateTime) {
      const remDate = new Date(n.reminderDateTime);
      const now = new Date();
      const diffMs = remDate - now;

      if (diffMs <= 0) {
        reminderText = "🔔 Zamanı Geldi!";
      } else {
        const diffMins = Math.round(diffMs / 60000);
        if (diffMins < 60) {
          reminderText = `⏰ ${diffMins} Dk Sonra`;
        } else {
          const diffHours = Math.round(diffMins / 60);
          reminderText = `⏰ ${diffHours} Saat Sonra`;
        }
      }
    }

    return `
      <div class="future-plan-card">
        <div class="plan-card-top">
          <div class="plan-title-wrap">
            <span class="plan-category-icon">${n.category || '📝'}</span>
            <h5>${escapeHtml(n.title)}</h5>
          </div>
          ${n.reminderEnabled ? `<span class="countdown-badge reminder-active">${reminderText}</span>` : ''}
        </div>
        ${n.body ? `<p class="plan-notes">${escapeHtml(n.body)}</p>` : ''}
        <div class="plan-actions-row">
          <span style="font-size:0.75rem; color:var(--text-sub);">
            ${n.reminderDateTime ? '⏰ ' + new Date(n.reminderDateTime).toLocaleString('tr-TR', { day:'numeric', month:'short', hour:'2-digit', minute:'2-digit' }) : ''}
          </span>
          <button class="btn-icon" onclick="openNoteModalForEdit('${n.id}')" title="Düzenle">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M11 4H4a2 2 0 0 1-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
          </button>
        </div>
      </div>
    `;
  }).join('');
}

function checkAndTriggerNoteNotifications() {
  const now = new Date();

  userNotes.forEach(note => {
    if (!note.reminderEnabled || !note.reminderDateTime) return;

    const remDate = new Date(note.reminderDateTime);
    const diffMs = remDate - now;

    // Trigger notification when reminder time is reached (within 30 seconds window)
    if (diffMs <= 30000 && !sentNotificationIds.has(note.id + "_rem")) {
      sentNotificationIds.add(note.id + "_rem");
      localStorage.setItem("love_sent_notif_ids", JSON.stringify(Array.from(sentNotificationIds)));

      const notifObj = {
        id: "notif_note_" + Date.now(),
        noteId: note.id,
        title: `📝 Not Hatırlatıcı: ${note.title}`,
        body: `${note.body || 'Hatırlatıcı zamanı geldi! ❤️'}`,
        date: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit", day: "numeric", month: "short" }),
        read: false
      };

      addNotificationItem(notifObj);
      sendNativeLockscreenNotification(notifObj.title, notifObj.body, note.id);
    }
  });
}

// --- NOTIFICATION & REMINDER SYSTEM ---
function checkAndTriggerPlanNotifications() {
  const now = new Date();

  futurePlans.forEach(plan => {
    if (plan.status === "completed") return;

    const targetDateObj = new Date(plan.targetDate);
    const diffMs = targetDateObj - now;

    if (diffMs <= 300000 && !sentNotificationIds.has(plan.id + "_due")) {
      sentNotificationIds.add(plan.id + "_due");
      localStorage.setItem("love_sent_notif_ids", JSON.stringify(Array.from(sentNotificationIds)));

      const notifObj = {
        id: "notif_" + Date.now(),
        planId: plan.id,
        title: `${plan.category || '✨'} Günü Geldi: ${plan.title}`,
        body: `Bugün beklediğiniz plan zamanı geldi! 🎉 ${plan.notes || ''}`,
        date: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit", day: "numeric", month: "short" }),
        read: false
      };

      addNotificationItem(notifObj);
      sendNativeLockscreenNotification(notifObj.title, notifObj.body, plan.id);
    }
    else if (diffMs > 0 && diffMs <= 86400000 && !sentNotificationIds.has(plan.id + "_1day")) {
      sentNotificationIds.add(plan.id + "_1day");
      localStorage.setItem("love_sent_notif_ids", JSON.stringify(Array.from(sentNotificationIds)));

      const notifObj = {
        id: "notif_" + Date.now(),
        planId: plan.id,
        title: `⏳ Yarın Planınız Var: ${plan.title}`,
        body: `Hatırlatma: Yarın ${plan.title} planınız gerçekleşecek! ${plan.category || ''}`,
        date: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit", day: "numeric", month: "short" }),
        read: false
      };

      addNotificationItem(notifObj);
      sendNativeLockscreenNotification(notifObj.title, notifObj.body, plan.id);
    }
  });
}

function sendNativeLockscreenNotification(title, body, tag) {
  if (!("Notification" in window)) return;

  if (Notification.permission === "granted") {
    triggerShowNotification(title, body, tag);
  }
}

function triggerShowNotification(title, body, tag) {
  const options = {
    body: body,
    icon: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" rx="100" fill="%23ff2a6d"/><path d="M256 448l-30.8-28.08C115.2 320 48 259.2 48 184 48 122.4 96.4 74 158 74c34.8 0 68.2 16.2 90 41.8C270.8 90.2 304.2 74 339 74c61.6 0 110 48.4 110 110 0 75.2-67.2 136-177.2 236.08L256 448z" fill="white"/></svg>',
    badge: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><circle cx="256" cy="256" r="200" fill="%23ff2a6d"/></svg>',
    vibrate: [200, 100, 200],
    tag: tag || 'love-counter-plan',
    renotify: true,
    requireInteraction: false
  };

  if (navigator.serviceWorker && navigator.serviceWorker.ready) {
    navigator.serviceWorker.ready.then(reg => {
      reg.showNotification(title, options);
    });
  } else {
    new Notification(title, options);
  }
}

function renderNotifications() {
  const badge = document.getElementById("notifBadge");
  const list = document.getElementById("notificationsList");
  const permBanner = document.getElementById("notifPermBanner");

  if (permBanner) {
    permBanner.style.display = ("Notification" in window && Notification.permission !== "granted") ? "block" : "none";
  }

  const unreadCount = notifications.filter(n => !n.read).length;
  if (badge) {
    badge.innerText = unreadCount;
    badge.style.display = unreadCount > 0 ? "flex" : "none";
  }

  if (!list) return;

  if (notifications.length === 0) {
    list.innerHTML = `
      <div style="text-align:center; padding: 24px; color: var(--text-muted);">
        <p>Henüz bildiriminiz yok 🔔</p>
        <p style="font-size:0.8rem; margin-top:4px;">Gelecek planlarınız ve özel not hatırlatıcılarınız günü geldiğinde kilit ekranınızda haber verilecektir.</p>
      </div>
    `;
    return;
  }

  list.innerHTML = notifications.map(n => `
    <div class="notif-item ${n.read ? '' : 'unread'}">
      <div class="notif-item-left">
        <span class="notif-icon">${n.category || '🔔'}</span>
        <div>
          <div class="notif-title">${escapeHtml(n.title)}</div>
          <div class="notif-body">${escapeHtml(n.body)}</div>
          <div class="notif-time">${n.date}</div>
        </div>
      </div>
      <button class="btn-delete-notif" onclick="deleteNotificationItem('${n.id}')" title="Bildirimi Sil">&times;</button>
    </div>
  `).join('');
}

// --- CANVAS WIDGET GENERATOR (HER SAYI TEK TEK KALBİN İÇİNDE) ---
function renderWidgetCanvas() {
  const canvas = document.getElementById("widgetCanvas");
  const ctx = canvas.getContext("2d");

  const width = canvas.width;  // 1080
  const height = canvas.height; // 1920

  // Background Gradient
  const grad = ctx.createLinearGradient(0, 0, width, height);
  grad.addColorStop(0, '#0f0c20');
  grad.addColorStop(0.5, '#2b0826');
  grad.addColorStop(1, '#0b0410');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, width, height);

  // Decorative Background Floating Hearts
  drawGlowingHeart(ctx, width * 0.15, height * 0.15, 140, 'rgba(255, 42, 109, 0.15)');
  drawGlowingHeart(ctx, width * 0.85, height * 0.85, 160, 'rgba(255, 42, 109, 0.12)');

  // Title / Couples Names
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 68px "Outfit", sans-serif';
  ctx.textAlign = 'center';
  const names = `${appState.partner1 || 'Ahmet'} & ${appState.partner2 || 'Ayşe'}`;
  ctx.fillText(names, width / 2, height * 0.30);

  ctx.fillStyle = '#ff85a2';
  ctx.font = '36px "Outfit", sans-serif';
  ctx.fillText('Birlikte Geçen Her An ❤️', width / 2, height * 0.35);

  // Widget Container Backdrop
  const boxW = 960;
  const boxH = 460;
  const boxX = (width - boxW) / 2;
  const boxY = height * 0.40;

  ctx.fillStyle = 'rgba(255, 255, 255, 0.06)';
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
  ctx.lineWidth = 4;
  roundRect(ctx, boxX, boxY, boxW, boxH, 40, true, true);

  // Current counter values
  const yVal = document.getElementById("counterYears").innerText;
  const mVal = document.getElementById("counterMonths").innerText;
  const dVal = document.getElementById("counterDays").innerText;
  const hVal = document.getElementById("counterHours").innerText;
  const minVal = document.getElementById("counterMinutes").innerText;

  const units = [
    { label: 'YIL', val: yVal },
    { label: 'AY', val: mVal },
    { label: 'GÜN', val: dVal },
    { label: 'SAAT', val: hVal },
    { label: 'DK', val: minVal }
  ];

  const colWidth = boxW / 5;
  units.forEach((u, i) => {
    const cx = boxX + colWidth * i + colWidth / 2;
    const cy = boxY + boxH / 2 - 35;
    const heartSize = 165;

    // Draw Individual Heart Shape for this specific number!
    drawWidgetHeartShape(ctx, cx, cy, heartSize, 'rgba(255, 42, 109, 0.35)', '#ff2a6d');

    // Render Number Inside Center of Heart
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 52px "Outfit", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(u.val, cx, cy + 50);

    // Render Unit Label Inside/Below Heart
    ctx.fillStyle = '#ffb703';
    ctx.font = 'bold 24px "Outfit", sans-serif';
    ctx.fillText(u.label, cx, cy + 96);
  });

  // Footer Quote
  ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
  ctx.font = 'italic 34px "Outfit", sans-serif';
  ctx.fillText('"Seni Sevmek En Güzel Zamanı Yaşamaktır"', width / 2, height * 0.78);
}

function drawWidgetHeartShape(ctx, cx, cy, size, fillColor, strokeColor) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.beginPath();
  const topCurveHeight = size * 0.3;
  ctx.moveTo(0, topCurveHeight);
  ctx.bezierCurveTo(0, 0, -size / 2, 0, -size / 2, topCurveHeight);
  ctx.bezierCurveTo(-size / 2, (size + topCurveHeight) / 2, 0, size, 0, size);
  ctx.bezierCurveTo(0, size, size / 2, (size + topCurveHeight) / 2, size / 2, topCurveHeight);
  ctx.bezierCurveTo(size / 2, 0, 0, 0, 0, topCurveHeight);
  ctx.closePath();
  ctx.fillStyle = fillColor;
  ctx.fill();
  if (strokeColor) {
    ctx.strokeStyle = strokeColor;
    ctx.lineWidth = 4;
    ctx.stroke();
  }
  ctx.restore();
}

function drawGlowingHeart(ctx, cx, cy, size, color) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.beginPath();
  const topCurveHeight = size * 0.3;
  ctx.moveTo(0, topCurveHeight);
  ctx.bezierCurveTo(0, 0, -size / 2, 0, -size / 2, topCurveHeight);
  ctx.bezierCurveTo(-size / 2, (size + topCurveHeight) / 2, 0, size, 0, size);
  ctx.bezierCurveTo(0, size, size / 2, (size + topCurveHeight) / 2, size / 2, topCurveHeight);
  ctx.bezierCurveTo(size / 2, 0, 0, 0, 0, topCurveHeight);
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
  ctx.restore();
}

function roundRect(ctx, x, y, width, height, radius, fill, stroke) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
  if (fill) ctx.fill();
  if (stroke) ctx.stroke();
}

function downloadWidgetImage() {
  const canvas = document.getElementById("widgetCanvas");
  const link = document.createElement("a");
  link.download = `Ask_Sayaci_Kilit_Ekrani_Widget_${Date.now()}.png`;
  link.href = canvas.toDataURL("image/png");
  link.click();
}

// --- PWA INSTALL PROMPT LOGIC ---
let deferredPrompt = null;
function setupPwaInstaller() {
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    const banner = document.getElementById("pwaInstallBanner");
    if (banner) banner.style.display = "flex";
  });

  document.getElementById("btnPwaInstall")?.addEventListener("click", async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        console.log('PWA Uygulama olarak yüklendi');
      }
      deferredPrompt = null;
      document.getElementById("pwaInstallBanner").style.display = "none";
    } else {
      alert("Safari / iOS kullanıyorsanız: Alt kısımdaki Paylaş butonuna basıp 'Ana Ekrana Ekle' seçeneğine dokunun ❤️");
    }
  });

  document.getElementById("closePwaBanner")?.addEventListener("click", () => {
    const banner = document.getElementById("pwaInstallBanner");
    if (banner) banner.style.display = "none";
  });
}

// --- NOTE MODAL & REMINDER LOGIC ---
function openNoteModalForNew() {
  document.getElementById("noteId").value = "";
  document.getElementById("noteTitle").value = "";
  document.getElementById("noteCategory").value = "💖";
  document.getElementById("noteBody").value = "";
  document.getElementById("noteReminderEnabled").checked = false;
  document.getElementById("reminderTimeControls").style.display = "none";
  
  // Default reminder date time = 1 hour from now
  const defaultRem = new Date(Date.now() + 3600000).toISOString().slice(0, 16);
  document.getElementById("noteReminderDateTime").value = defaultRem;

  document.getElementById("btnDeleteNote").style.display = "none";
  document.getElementById("noteModalTitle").innerText = "Özel Not & Hatırlatıcı Ekle 📝";
  document.getElementById("noteModal").classList.add("active");
}

function openNoteModalForEdit(id) {
  const note = userNotes.find(n => n.id === id);
  if (!note) return;

  document.getElementById("noteId").value = note.id;
  document.getElementById("noteTitle").value = note.title || "";
  document.getElementById("noteCategory").value = note.category || "💖";
  document.getElementById("noteBody").value = note.body || "";
  document.getElementById("noteReminderEnabled").checked = !!note.reminderEnabled;
  document.getElementById("reminderTimeControls").style.display = note.reminderEnabled ? "block" : "none";
  document.getElementById("noteReminderDateTime").value = note.reminderDateTime || new Date(Date.now() + 3600000).toISOString().slice(0, 16);

  document.getElementById("btnDeleteNote").style.display = "inline-block";
  document.getElementById("noteModalTitle").innerText = "Notu & Hatırlatıcıyı Düzenle 📝";
  document.getElementById("noteModal").classList.add("active");
}

function closeNoteModal() {
  document.getElementById("noteModal").classList.remove("active");
}

async function handleNoteFormSubmit(e) {
  e.preventDefault();
  const existingId = document.getElementById("noteId").value;
  const id = existingId || "note_" + Date.now();

  const noteObj = {
    id,
    title: document.getElementById("noteTitle").value.trim(),
    category: document.getElementById("noteCategory").value,
    body: document.getElementById("noteBody").value.trim(),
    reminderEnabled: document.getElementById("noteReminderEnabled").checked,
    reminderDateTime: document.getElementById("noteReminderDateTime").value,
    createdAt: new Date().toISOString()
  };

  await saveUserNote(noteObj);
  renderUserNotes();
  closeNoteModal();
}

async function handleNoteDelete() {
  const id = document.getElementById("noteId").value;
  if (id && confirm("Bu notu silmek istediğinizden emin misiniz?")) {
    await deleteUserNote(id);
    renderUserNotes();
    closeNoteModal();
  }
}

// --- FUTURE PLAN MODAL LOGIC ---
function openFutureModalForDate(dateStr) {
  document.getElementById("futurePlanId").value = "";
  document.getElementById("futureTitle").value = "";
  document.getElementById("futureCategory").value = "✈️";
  document.getElementById("futureNotes").value = "";
  document.getElementById("futureStatus").value = "planned";
  document.getElementById("futureTargetDate").value = `${dateStr}T12:00`;
  document.getElementById("btnDeleteFuturePlan").style.display = "none";
  document.getElementById("futureModalTitle").innerText = "Gelecek Planı Ekle ✨";
  document.getElementById("futureModal").classList.add("active");
}

function openFutureModalForEdit(id) {
  const plan = futurePlans.find(p => p.id === id);
  if (!plan) return;

  document.getElementById("futurePlanId").value = plan.id;
  document.getElementById("futureTitle").value = plan.title || "";
  document.getElementById("futureCategory").value = plan.category || "✈️";
  document.getElementById("futureNotes").value = plan.notes || "";
  document.getElementById("futureStatus").value = plan.status || "planned";
  document.getElementById("futureTargetDate").value = plan.targetDate || "";
  document.getElementById("btnDeleteFuturePlan").style.display = "inline-block";
  document.getElementById("futureModalTitle").innerText = "Gelecek Planını Düzenle ✨";
  document.getElementById("futureModal").classList.add("active");
}

function closeFutureModal() {
  document.getElementById("futureModal").classList.remove("active");
}

async function handleFutureFormSubmit(e) {
  e.preventDefault();
  const existingId = document.getElementById("futurePlanId").value;
  const id = existingId || "plan_" + Date.now();

  const planObj = {
    id,
    title: document.getElementById("futureTitle").value.trim(),
    targetDate: document.getElementById("futureTargetDate").value,
    category: document.getElementById("futureCategory").value,
    notes: document.getElementById("futureNotes").value.trim(),
    status: document.getElementById("futureStatus").value
  };

  await saveFuturePlan(planObj);
  renderFuturePlans();
  renderFutureCalendar(currentFutureCalDate);
  closeFutureModal();
}

async function handleFuturePlanDelete() {
  const id = document.getElementById("futurePlanId").value;
  if (id && confirm("Bu gelecek planını silmek istediğinizden emin misiniz?")) {
    await deleteFuturePlan(id);
    renderFuturePlans();
    renderFutureCalendar(currentFutureCalDate);
    closeFutureModal();
  }
}

// --- SETUP ALL EVENT LISTENERS ---
function setupEventListeners() {
  document.getElementById("tabCalendar").addEventListener("click", () => switchTab("calendar"));
  document.getElementById("tabTimeline").addEventListener("click", () => switchTab("timeline"));
  document.getElementById("tabFuture").addEventListener("click", () => switchTab("future"));
  document.getElementById("tabNotes").addEventListener("click", () => switchTab("notes"));

  document.getElementById("bnavCalendar").addEventListener("click", () => switchTab("calendar"));
  document.getElementById("bnavTimeline").addEventListener("click", () => switchTab("timeline"));
  document.getElementById("bnavFuture").addEventListener("click", () => switchTab("future"));
  document.getElementById("bnavNotes").addEventListener("click", () => switchTab("notes"));

  document.getElementById("btnNotifications").addEventListener("click", () => {
    notifications.forEach(n => n.read = true);
    localStorage.setItem("love_counter_notifs", JSON.stringify(notifications));
    renderNotifications();
    document.getElementById("notificationsModal").classList.add("active");
  });
  document.getElementById("closeNotificationsModal").addEventListener("click", () => {
    document.getElementById("notificationsModal").classList.remove("active");
  });
  document.getElementById("btnClearAllNotifs").addEventListener("click", clearAllNotifications);
  document.getElementById("btnRequestNotifPerm").addEventListener("click", () => {
    if ("Notification" in window) {
      Notification.requestPermission().then(permission => {
        renderNotifications();
        if (permission === "granted") {
          sendNativeLockscreenNotification("Bildirimler Etkinleştirildi ❤️", "Kilit ekranınızda gelecek planlarınız ve özel not hatırlatıcılarınız günü geldiğinde bildirilecektir.");
        }
      });
    }
  });

  document.getElementById("prevMonthBtn").addEventListener("click", () => {
    currentCalDate.setMonth(currentCalDate.getMonth() - 1);
    renderCalendar(currentCalDate);
  });
  document.getElementById("nextMonthBtn").addEventListener("click", () => {
    currentCalDate.setMonth(currentCalDate.getMonth() + 1);
    renderCalendar(currentCalDate);
  });

  document.getElementById("prevFutureMonthBtn").addEventListener("click", () => {
    currentFutureCalDate.setMonth(currentFutureCalDate.getMonth() - 1);
    renderFutureCalendar(currentFutureCalDate);
  });
  document.getElementById("nextFutureMonthBtn").addEventListener("click", () => {
    currentFutureCalDate.setMonth(currentFutureCalDate.getMonth() + 1);
    renderFutureCalendar(currentFutureCalDate);
  });

  document.getElementById("btnSettings").addEventListener("click", openSettingsModal);
  document.getElementById("closeSettingsModal").addEventListener("click", closeSettingsModal);
  document.getElementById("settingsForm").addEventListener("submit", handleSettingsSubmit);

  document.getElementById("closeMemoryModal").addEventListener("click", closeMemoryModal);
  document.getElementById("memoryForm").addEventListener("submit", handleMemorySubmit);
  document.getElementById("btnDeleteMemory").addEventListener("click", handleMemoryDelete);
  document.getElementById("btnAddNewMemoryDirect").addEventListener("click", () => {
    const todayStr = new Date().toISOString().slice(0, 10);
    openMemoryModalForDate(todayStr);
  });
  document.getElementById("memoryPhotosInput").addEventListener("change", handlePhotoSelect);

  document.getElementById("btnAddNewFuturePlan").addEventListener("click", () => {
    const tomorrowStr = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
    openFutureModalForDate(tomorrowStr);
  });
  document.getElementById("closeFutureModal").addEventListener("click", closeFutureModal);
  document.getElementById("futureForm").addEventListener("submit", handleFutureFormSubmit);
  document.getElementById("btnDeleteFuturePlan").addEventListener("click", handleFuturePlanDelete);

  // Note Modal Event Listeners
  document.getElementById("btnAddNewNote").addEventListener("click", openNoteModalForNew);
  document.getElementById("closeNoteModal").addEventListener("click", closeNoteModal);
  document.getElementById("noteForm").addEventListener("submit", handleNoteFormSubmit);
  document.getElementById("btnDeleteNote").addEventListener("click", handleNoteDelete);

  document.getElementById("noteReminderEnabled").addEventListener("change", (e) => {
    document.getElementById("reminderTimeControls").style.display = e.target.checked ? "block" : "none";
  });

  // Quick Time Preset Buttons
  document.querySelectorAll(".btn-quick-time").forEach(btn => {
    btn.addEventListener("click", () => {
      const minutes = parseInt(btn.dataset.minutes, 10);
      if (!isNaN(minutes)) {
        const target = new Date(Date.now() + minutes * 60000);
        document.getElementById("noteReminderDateTime").value = target.toISOString().slice(0, 16);
      }
    });
  });

  // Note Filter Buttons
  document.querySelectorAll(".note-filter-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".note-filter-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      activeNoteFilter = btn.dataset.filter;
      renderUserNotes();
    });
  });

  document.getElementById("btnLockscreenWidget").addEventListener("click", openLockscreenModal);
  document.getElementById("closeLockscreenModal").addEventListener("click", closeLockscreenModal);
  document.getElementById("subtabAmbient").addEventListener("click", () => switchSubtab("ambient"));
  document.getElementById("subtabGenerator").addEventListener("click", () => switchSubtab("generator"));
  document.getElementById("btnGenerateWidget").addEventListener("click", renderWidgetCanvas);
  document.getElementById("btnDownloadWidget").addEventListener("click", downloadWidgetImage);
  document.getElementById("btnToggleFullscreenAmbient").addEventListener("click", toggleFullscreenAmbient);

  document.getElementById("closePhotoViewer").addEventListener("click", () => {
    document.getElementById("photoViewerModal").classList.remove("active");
  });

  document.getElementById("btnExportData").addEventListener("click", exportDataJSON);
  document.getElementById("importFile").addEventListener("change", importDataJSON);
}

function switchTab(tabName) {
  document.getElementById("tabCalendar").classList.toggle("active", tabName === "calendar");
  document.getElementById("tabTimeline").classList.toggle("active", tabName === "timeline");
  document.getElementById("tabFuture").classList.toggle("active", tabName === "future");
  document.getElementById("tabNotes").classList.toggle("active", tabName === "notes");

  document.getElementById("bnavCalendar").classList.toggle("active", tabName === "calendar");
  document.getElementById("bnavTimeline").classList.toggle("active", tabName === "timeline");
  document.getElementById("bnavFuture").classList.toggle("active", tabName === "future");
  document.getElementById("bnavNotes").classList.toggle("active", tabName === "notes");

  document.getElementById("calendarSection").classList.toggle("active", tabName === "calendar");
  document.getElementById("timelineSection").classList.toggle("active", tabName === "timeline");
  document.getElementById("futureSection").classList.toggle("active", tabName === "future");
  document.getElementById("notesSection").classList.toggle("active", tabName === "notes");

  if (tabName === "timeline") {
    renderTimeline();
  } else if (tabName === "future") {
    renderFuturePlans();
    renderFutureCalendar(currentFutureCalDate);
  } else if (tabName === "notes") {
    renderUserNotes();
  }
}

// Settings Modal Handler
function openSettingsModal() {
  document.getElementById("inputPartner1").value = appState.partner1 || "";
  document.getElementById("inputPartner2").value = appState.partner2 || "";
  document.getElementById("inputStartDate").value = appState.startDate || "";
  document.getElementById("settingsModal").classList.add("active");
}

function closeSettingsModal() {
  document.getElementById("settingsModal").classList.remove("active");
}

async function handleSettingsSubmit(e) {
  e.preventDefault();
  appState.partner1 = document.getElementById("inputPartner1").value.trim();
  appState.partner2 = document.getElementById("inputPartner2").value.trim();
  appState.startDate = document.getElementById("inputStartDate").value;

  const file1 = document.getElementById("inputAvatar1").files[0];
  const file2 = document.getElementById("inputAvatar2").files[0];

  if (file1) appState.avatar1 = await readFileAsBase64(file1);
  if (file2) appState.avatar2 = await readFileAsBase64(file2);

  saveAppState();
  renderCouplesHeader();
  updateCounterDisplay();
  renderCalendar(currentCalDate);
  closeSettingsModal();
}

// Memory Modal Handler
function openMemoryModalForDate(dateStr) {
  selectedMemoryPhotos = [];
  document.getElementById("memoryDate").value = dateStr;

  const formattedDate = new Date(dateStr).toLocaleDateString("tr-TR", {
    day: "numeric", month: "long", year: "numeric"
  });
  document.getElementById("memorySelectedDateText").innerText = `📅 Seçilen Tarih: ${formattedDate}`;

  const existing = memories.find(m => m.date === dateStr);
  if (existing) {
    document.getElementById("memoryId").value = existing.id;
    document.getElementById("memoryTitle").value = existing.title || "";
    document.getElementById("memoryCategory").value = existing.category || "❤️";
    document.getElementById("memoryNotes").value = existing.notes || "";
    document.getElementById("btnDeleteMemory").style.display = "inline-block";
    selectedMemoryPhotos = existing.photos ? [...existing.photos] : [];
    document.getElementById("memoryModalTitle").innerText = "Anıyı Düzenle";
  } else {
    document.getElementById("memoryId").value = "";
    document.getElementById("memoryTitle").value = "";
    document.getElementById("memoryCategory").value = "❤️";
    document.getElementById("memoryNotes").value = "";
    document.getElementById("btnDeleteMemory").style.display = "none";
    document.getElementById("memoryModalTitle").innerText = "Tarih İçin Anı / Not Ekle";
  }

  renderPhotoPreviews();
  document.getElementById("memoryModal").classList.add("active");
}

function closeMemoryModal() {
  document.getElementById("memoryModal").classList.remove("active");
}

async function handlePhotoSelect(e) {
  const files = Array.from(e.target.files);
  for (const file of files) {
    const base64 = await readFileAsBase64(file);
    selectedMemoryPhotos.push(base64);
  }
  renderPhotoPreviews();
}

function renderPhotoPreviews() {
  const container = document.getElementById("photoPreviewContainer");
  container.innerHTML = selectedMemoryPhotos.map((p, idx) => `
    <div style="position:relative">
      <img src="${p}" class="photo-preview-item">
      <button type="button" onclick="removePreviewPhoto(${idx})" style="position:absolute;top:-6px;right:-6px;background:#ff0055;color:#fff;border:none;border-radius:50%;width:20px;height:20px;cursor:pointer;font-size:12px">&times;</button>
    </div>
  `).join('');
}

function removePreviewPhoto(idx) {
  selectedMemoryPhotos.splice(idx, 1);
  renderPhotoPreviews();
}

async function handleMemorySubmit(e) {
  e.preventDefault();
  const date = document.getElementById("memoryDate").value;
  const existingId = document.getElementById("memoryId").value;
  const id = existingId || "mem_" + Date.now();

  const memoryObj = {
    id,
    date,
    title: document.getElementById("memoryTitle").value.trim(),
    category: document.getElementById("memoryCategory").value,
    notes: document.getElementById("memoryNotes").value.trim(),
    photos: selectedMemoryPhotos
  };

  await saveMemory(memoryObj);
  renderCalendar(currentCalDate);
  renderTimeline();
  closeMemoryModal();
}

async function handleMemoryDelete() {
  const id = document.getElementById("memoryId").value;
  if (id && confirm("Bu anıyı silmek istediğinizden emin misiniz?")) {
    await deleteMemory(id);
    renderCalendar(currentCalDate);
    renderTimeline();
    closeMemoryModal();
  }
}

// Lockscreen Modal Logic
function openLockscreenModal() {
  updateAmbientClock();
  document.getElementById("lockscreenWidgetModal").classList.add("active");
  switchSubtab("ambient");
}

function closeLockscreenModal() {
  document.getElementById("lockscreenWidgetModal").classList.remove("active");
}

function switchSubtab(tab) {
  document.getElementById("subtabAmbient").classList.toggle("active", tab === "ambient");
  document.getElementById("subtabGenerator").classList.toggle("active", tab === "generator");
  document.getElementById("ambientModeView").classList.toggle("active", tab === "ambient");
  document.getElementById("generatorModeView").classList.toggle("active", tab === "generator");

  if (tab === "generator") {
    renderWidgetCanvas();
  }
}

function updateAmbientClock() {
  const now = new Date();
  const clockText = now.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
  const dateText = now.toLocaleDateString("tr-TR", { day: "numeric", month: "long", weekday: "long" });

  const ambClock = document.getElementById("ambientClock");
  const ambDate = document.getElementById("ambientDate");
  if (ambClock) ambClock.innerText = clockText;
  if (ambDate) ambDate.innerText = dateText;
}

function updateAmbientLockscreen() {
  updateAmbientClock();
}

function toggleFullscreenAmbient() {
  const frame = document.querySelector(".ambient-phone-frame");
  if (frame.requestFullscreen) {
    frame.requestFullscreen();
  } else if (frame.webkitRequestFullscreen) {
    frame.webkitRequestFullscreen();
  }
}

// Photo Viewer
function openPhotoViewer(src, caption) {
  document.getElementById("fullPhotoImg").src = src;
  document.getElementById("fullPhotoCaption").innerText = caption || "";
  document.getElementById("photoViewerModal").classList.add("active");
}

// Backup & Restore
function exportDataJSON() {
  const exportData = {
    appState,
    memories,
    futurePlans,
    userNotes,
    notifications,
    version: 4,
    exportedAt: new Date().toISOString()
  };
  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(exportData, null, 2));
  const link = document.createElement("a");
  link.setAttribute("href", dataStr);
  link.setAttribute("download", `Ask_Sayaci_Yedek_${new Date().toISOString().slice(0, 10)}.json`);
  document.body.appendChild(link);
  link.click();
  link.remove();
}

function importDataJSON(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = async (event) => {
    try {
      const data = JSON.parse(event.target.result);
      if (data.appState) {
        appState = { ...DEFAULT_STATE, ...data.appState };
        saveAppState();
      }
      if (data.memories && Array.isArray(data.memories)) {
        memories = data.memories;
        for (const m of memories) {
          await saveMemory(m);
        }
      }
      if (data.futurePlans && Array.isArray(data.futurePlans)) {
        futurePlans = data.futurePlans;
        for (const p of futurePlans) {
          await saveFuturePlan(p);
        }
      }
      if (data.userNotes && Array.isArray(data.userNotes)) {
        userNotes = data.userNotes;
        for (const n of userNotes) {
          await saveUserNote(n);
        }
      }
      if (data.notifications && Array.isArray(data.notifications)) {
        notifications = data.notifications;
        for (const n of notifications) {
          await addNotificationItem(n);
        }
      }
      alert("Yedek başarıyla yüklendi! ❤️");
      location.reload();
    } catch (err) {
      alert("Hata: Geçersiz yedek dosyası!");
      console.error(err);
    }
  };
  reader.readAsText(file);
}

// Helpers
function readFileAsBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, function(m) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m];
  });
}

// Service Worker Registration
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(err => console.log('SW Reg Error:', err));
  });
}
